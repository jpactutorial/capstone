<?php
include_once("common.php");
$_SESSION['userData']=null;
header("Location: signin.php");
?>